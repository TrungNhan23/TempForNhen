#!/usr/bin/bash

first_level=$1
second_level=$2
third_level=$3
name=$4

makedir() {
    mkdir -p $1
    mkdir -p $1/$2
    mkdir -p $1/$2/$3
    touch $1/$2/$3/$4
}

cd src; makedir ${first_level} ${second_level} ${third_level} ${name}.cpp; cd -
cd include; makedir ${first_level} ${second_level} ${third_level} ${name}.h; cd -