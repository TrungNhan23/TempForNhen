#include <iostream>
#include <chrono>
#include <thread>
#include <mutex>

#include <boost/log/trivial.hpp>

extern "C"
{
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
}

#define INFO BOOST_LOG_TRIVIAL(info)

void doSomething(void)
{
    INFO << "Non-member function started (" << syscall(SYS_gettid) << ")" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5));
    INFO << "Non-member function ended (" << syscall(SYS_gettid) << ")" << std::endl;
}

void doSomethingWithLvalue(int &value)
{
    (void)value;
    INFO << "Do something with l-value started (" << syscall(SYS_gettid) << ")" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(1));
    INFO << "Do something with l-value ended (" << syscall(SYS_gettid) << ")" << std::endl;
}

void doSomethingWithRvalue(int &&value)
{
    (void)value;
    INFO << "Do something with r-value started (" << syscall(SYS_gettid) << ")" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(1));
    INFO << "Do something with r-value ended (" << syscall(SYS_gettid) << ")" << std::endl;
}

void doSomethingWithNonRef(int value)
{
    (void)value;
    INFO << "Do something with non-reference value started (" << syscall(SYS_gettid) << ")" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(1));
    INFO << "Do something with non-reference value ended (" << syscall(SYS_gettid) << ")" << std::endl;
}

class TaskA
{
public:
    void doSomething(void)
    {
        INFO << "Member function started (" << syscall(SYS_gettid) << ")" << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(10));
        INFO << "Member function ended (" << syscall(SYS_gettid) << ")" << std::endl;
    }
};

class TaskB
{
public:
    void operator()()
    {
        INFO << "Functor started (" << syscall(SYS_gettid) << ")" << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(15));
        INFO << "Functor ended (" << syscall(SYS_gettid) << ")" << std::endl;
    }
};

class ScopedThread
{
public:
    explicit ScopedThread(std::thread t) : m_thread(std::move(t))
    {
        if (not m_thread.joinable())
            throw std::logic_error("No thread");
    }
    ~ScopedThread()
    {
        m_thread.join();
    }
    ScopedThread(ScopedThread const &) = delete;
    ScopedThread &operator=(ScopedThread const &) = delete;

private:
    std::thread m_thread;
};

struct SharedData
{
    int value;
    std::mutex m;
};

class Singleton {
public:
    Singleton(const Singleton&)= delete;
    Singleton& operator=(const Singleton&)= delete;

    static Singleton* getInstance(){
        std::call_once(initInstanceFlag,Singleton::initSingleton);
        return instance;
    }

    static void initSingleton(){
        INFO << "Initialize the singleton" << std::endl;
        instance = new Singleton();
    }

    void doSomething(void)
    {
        INFO << "Singleton instance does something" << std::endl;
    }

private:
    static std::once_flag initInstanceFlag;
    static Singleton* instance;
    Singleton()= default;
    ~Singleton()= default;
};
std::once_flag Singleton::initInstanceFlag{};
Singleton* Singleton::instance{nullptr};

void runCreatingThreadDemo(void)
{
    std::thread thread_w_non_member_func{doSomething};

    std::thread thread_w_member_func{&TaskA::doSomething, TaskA()};

    std::thread thread_w_functor{TaskB()};

    std::thread thread_w_lambda([]()
                                {
                                    INFO << "Lambda started (" << syscall(SYS_gettid) << ")" << std::endl;
                                    std::this_thread::sleep_for(std::chrono::seconds(20));
                                    INFO << "Lambda ended (" << syscall(SYS_gettid) << ")" << std::endl;
                                });

    thread_w_non_member_func.join();
    INFO << "Non-member function terminated" << std::endl;

    thread_w_member_func.join();
    INFO << "Member function terminated" << std::endl;

    thread_w_functor.join();
    INFO << "Functor terminated" << std::endl;

    thread_w_lambda.join();
    INFO << "Lambda terminated" << std::endl;
}

void runManagingLifetimeDemo(void)
{
    std::thread thread_to_be_joined([]()
                                    {
                                        INFO << "Thread to be joined started (" << syscall(SYS_gettid) << ")" << std::endl;
                                        std::this_thread::sleep_for(std::chrono::seconds(2));
                                        INFO << "Thread to be joined ended (" << syscall(SYS_gettid) << ")" << std::endl;
                                    });
    std::this_thread::sleep_for(std::chrono::seconds(1));
    INFO << "Main thread is blocking" << std::endl;
    thread_to_be_joined.join();
    INFO << "Main thread continues running after being joined" << std::endl;
    std::thread thread_to_be_detached([]()
                                      {
                                          INFO << "Thread to be detached started (" << syscall(SYS_gettid) << ")" << std::endl;
                                          std::this_thread::sleep_for(std::chrono::seconds(4));
                                          INFO << "Thread to be detached ended (" << syscall(SYS_gettid) << ")" << std::endl;
                                      });
    thread_to_be_detached.detach();
    INFO << "Main thread continues running after being detached" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(6));
}

void runPassingArgumentsDemo(void)
{
    int x = 10;
    std::thread first_thread{doSomethingWithLvalue, std::ref(x)};
    first_thread.join();

    std::thread second_thread{doSomethingWithRvalue, x};
    second_thread.join();

    std::thread third_thread{doSomethingWithRvalue, 10};
    third_thread.join();

    std::thread fourth_thread{doSomethingWithNonRef, 10};
    fourth_thread.join();
}

void runTransferingOwnershipDemo(void)
{
    std::thread thread_w_non_member_func{doSomething};
    ScopedThread scopedThread(std::move(thread_w_non_member_func));
}

void runDataSynchronizationDemo(void)
{
    SharedData income;
    SharedData outcome;

    income.value = 0;
    outcome.value = 0;

    // Try lock
    std::thread manager_thread([&]()
                               {
                                   for (auto round = 0; round < 100; ++round)
                                   {
                                       (void)round;
                                       if (income.m.try_lock())
                                       {
                                           income.value += 10;
                                           income.m.unlock();
                                       }
                                       else
                                       {
                                           INFO << "Cannot lock income, manager waits" << std::endl;
                                           std::this_thread::sleep_for(std::chrono::milliseconds(10));
                                       }
                                   }
                               });

    std::thread hr_thread([&]()
                          {
                              for (auto round = 0; round < 100; ++round)
                              {
                                  (void)round;
                                  if (income.m.try_lock())
                                  {
                                    //   INFO << "Income: " << income.value << std::endl;
                                      income.m.unlock();
                                  }
                                  else
                                  {
                                      INFO << "Cannot lock income, hr waits" << std::endl;
                                      std::this_thread::sleep_for(std::chrono::milliseconds(10));
                                  }
                              }
                          });

    manager_thread.join();
    hr_thread.join();

    // Scoped lock
    std::thread crazy_thread([&](){
        std::scoped_lock guard(income.m, outcome.m);
        auto tmp = income.value;
        income.value = outcome.value;
        outcome.value = tmp;

        INFO << "Income: " << income.value << std::endl;
        INFO << "Outcome: " << outcome.value << std::endl;
    });
    crazy_thread.join();

    // Unique lock
    std::thread another_crazy_thread([&](){
        std::unique_lock<std::mutex> lock_income(income.m,std::defer_lock);
        std::unique_lock<std::mutex> lock_outcome(outcome.m,std::defer_lock);

        // He was waiting for 2 seconds
        std::this_thread::sleep_for(std::chrono::seconds(2));
        // Then he did something crazy...

        std::lock(lock_income, lock_outcome);
        auto tmp = income.value;
        income.value = outcome.value;
        outcome.value = tmp;

        INFO << "Income: " << income.value << std::endl;
        INFO << "Outcome: " << outcome.value << std::endl;
    });
    another_crazy_thread.join();

    // Call once
    std::thread thread_using_singleton([](){
        Singleton::getInstance()->doSomething();
    });
    std::thread another_thread_using_singleton([](){
        Singleton::getInstance()->doSomething();
    });
    thread_using_singleton.join();
    another_thread_using_singleton.join();
}

int main(int ac, char **av)
{
    // runCreatingThreadDemo();
    // runManagingLifetimeDemo();
    // runPassingArgumentsDemo();
    // runTransferingOwnershipDemo();
    // runDataSynchronizationDemo();
}