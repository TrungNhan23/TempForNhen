#include "CppUTest/TestHarness.h"

#include "bosch/training/example/Math.h"

TEST_GROUP(MathTest)
{
    example::Math *me;
    void setup() {
        me = new example::Math();
    }
    void teardown() {
        delete me;
    }
};

TEST(MathTest, div)
{
    int ret = me->div(2, 1);
    CHECK_EQUAL(2, ret);
}