# You need to do the following steps in order to run the example

## 1. Install boost library

    sudo apt install libboost-all-dev

## 2. Install gcovr

    sudo apt install gcovr

## 3. Clone cpputest then follow the build process

    git clone https://github.com/cpputest/cpputest.git

## 4. Build

    mkdir -p build
    cd build
    cmake ..  -DCppUTest_ROOT=../../cpputest
    cmake --build . --target tests
    ./tests/tests

## 5. Useful commands

    pstree -p `pidof tests`

