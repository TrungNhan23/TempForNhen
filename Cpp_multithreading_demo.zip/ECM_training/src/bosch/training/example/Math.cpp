#include "bosch/training/example/Math.h"

#include <iostream>

namespace example
{
    int Math::div(int x, int y)
    {
        return x / y;
    }
} // namespace example
