#!/usr/bin/bash

list=("include" "src")

for item in "${list[@]}"; do
    mkdir -p ${item}
done
