#pragma once

namespace example
{
    class Math
    {
    public:
        Math() = default;
        ~Math() = default;

        int div(int x, int y);
        int add(int x, int y);
    };
} // namespace example
